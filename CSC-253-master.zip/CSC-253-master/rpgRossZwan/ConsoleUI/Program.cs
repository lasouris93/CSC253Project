﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
* 12SEP2019
* CSC 253
* Grace Ross & Nick Zwan
* This program *TODO: ADD PROGRAM DESCRIPTION*
*/

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = false;

            // The four arrays
            string[] rooms = { "courtyard", "foyer", "hall", "library", "ballroom" };
            string[] weapons = { "knife", "lead pipe", "wrench", "candlestick" };
            string[] potions = { "health tonic", "strength elixir" };
            string[] treasures = { "ruby red slippers", "Excalibur", "tons of gold" };

            // The two lists
            List<string> items = new List<string>();
            List<string> mobs = new List<string>();


            int currentLocation = 0;
            do
            {
                DisplayMenu();
                string input = Console.ReadLine();

                switch (input)
                {
                    case "1":
                        Console.WriteLine($"Welcome! Here is your starting point!:");
                        // Display the rooms array
                        Console.WriteLine(rooms[currentLocation]);
                        Console.WriteLine("Enter n to go north or s to go south > ");
                        input = Console.ReadLine();


                        // EVENTUALLY MOVE TO ANOTHER METHOD ONCE ^ THAT PART ^ IS FIGURED OUT
                        // WITHOUT USING A LOT OF IF-ELSE STATEMENTS
                        if (input == "n")//Move up one Subscript in the room array.
                        {
                            currentLocation += 1;
                            Console.WriteLine(rooms[currentLocation]);

                        }
                        if (input == "s")//Move down one Subscript in room arrray.
                        {
                            currentLocation -= 1;
                            Console.WriteLine(rooms[currentLocation]);

                        }
                        
                        break;
                     
                
                    case "2":
                        // Display the weapons in alphabetical order
                        Array.Sort(weapons);
                        foreach (string weapon in weapons)
                        {
                            Console.WriteLine(weapon);
                        }
                        break;
                    case "3":
                        exit = true;
                        break;
                    default:
                        Console.WriteLine("Invalid input. Enter 1, 2 or 3.");
                        break;
                }

            } while (exit == false);

            Console.ReadLine();
        }

        public static void DisplayMenu()
        {
            Console.WriteLine("1. Run game\n2. Display weapons\n3. Exit\nEnter 1, 2 or 3 > ");
        }

    }
}
