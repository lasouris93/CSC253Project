﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GameClasses;

//This contains the classes needed to program the first iteration.

namespace GameClasses

{
    public class Room //Not sure if this is needed yet but is created for class room.
    {
        private int _location;
        private string _color;
        private string _loot;
        private string _name;

        public Room(int location, string color, string loot, string name)
        {
            Location = 0;
            Color = null;
            Loot = null;
            Name = null;
        }
        public int Location
        {
            get
            {
                return _location;
            }
            set
            {
                _location = value;
            }
        }

        public string Color
        {
            get
            {
                return _color;
            }
            set
            {
                _color = value;
            }
        }

        public string Loot
        {
            get
            {
                return _loot;
            }
            set
            {
                _loot = value;
            }
        }

        public string Name
        {
            get
            {
                return _name;
            }
            set
            {
                _name = value;
            }
        }


        public class Player //Class player to initialize starting values
        {
            private int _attackPoints;
            private int _healthPoints;
            private string _name;

            public Player(int attackPoints, int healthPoints, string name, string type)
            {
                AttackPoints = 15;
                healthPoints = 100;
                Name = "Adventurer";
            }
            public int AttackPoints
            {
                get
                {
                    return _attackPoints;
                }
                set
                {
                    _attackPoints = value;
                }
            }

            public int HealthPoints
            {
                get
                {
                    return _healthPoints;
                }
                set
                {
                    _healthPoints = value;
                }
            }

            public string Name
            {
                get
                {
                    return _name;
                }
                set
                {
                    _name = value;
                }
            }

            public class Goblin //First enemy for game.
            {
                private int _attackPoints;
                private int _healthPoints;
                private string _name;
                private string _type;


                public Goblin(int attackPoints, int healthPoints, string name, string type)
                {
                    AttackPoints = 15;
                    HealthPoints = 20;
                    Name = "Goblin the Defiler.";
                    Type = "Enemy";


                }

                public int AttackPoints
                {
                    get
                    {
                        return _attackPoints;
                    }
                    set
                    {
                        _attackPoints = value;
                    }
                }

                public int HealthPoints
                {
                    get
                    {
                        return _healthPoints;
                    }
                    set
                    {
                        _healthPoints = value;
                    }
                }

                public string Name
                {
                    get
                    {
                        return _name;
                    }
                    set
                    {
                        _name = value;
                    }
                }

                public string Type
                {
                    get
                    {
                        return _type;
                    }
                    set
                    {
                        _type = value;
                    }
                }

                public class Blade //First weapon(starter) for game. 
                {
                    private int _attackPower;
                    private int _durability;
                    private string _name;
                    private string _type;



                    public Blade(int attackPower, int durability, string name, string type)
                    {
                        AttackPower = 20;
                        Durability = 50;
                        Name = "Sword";
                        Type = "Piercing";
                    }

                    public int AttackPower
                    {
                        get
                        {
                            return _attackPower;
                        }
                        set
                        {
                            _attackPower = value;
                        }
                    }

                    public int Durability
                    {
                        get
                        {
                            return _durability;
                        }
                        set
                        {
                            _durability = value;
                        }
                    }

                    public string Name
                    {
                        get
                        {
                            return _name;
                        }
                        set
                        {
                            _name = value;
                        }
                    }

                    public string Type
                    {
                        get
                        {
                            return _type;
                        }
                        set
                        {
                            _type = value;
                        }

                    }
                    public class Inventory //Needed for inventory modules later. 
                    {
                        private int _weight;
                        private int _space;
                        private string _name;




                        public Inventory(int weight, int space, string name)
                        {
                            weight = 0;
                            space = 5;
                            Name = "Bag";

                        }

                        public int Weight
                        {
                            get
                            {
                                return _weight;
                            }
                            set
                            {
                                _weight = value;
                            }
                        }

                        public int Space
                        {
                            get
                            {
                                return _space;
                            }
                            set
                            {
                                _space = value;
                            }
                        }

                        public string Name
                        {
                            get
                            {
                                return _name;
                            }
                            set
                            {
                                _name = value;
                            }
                        }

                    }


                }

            }

        }

    }

}
